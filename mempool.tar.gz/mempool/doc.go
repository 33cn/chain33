package mempool

//mempool 模块的功能：实现交易暂存的功能。主要是解决共识模块可能比rpc模块速度慢的问题。
//模块的接口的设计：

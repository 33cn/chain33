// Copyright Fuzamei Corp. 2018 All Rights Reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package p2p

//p2p 网络模块：
//主要的功能是实现区块链数据的广播，交易的广播的功能。
//p2p 模块的接口：

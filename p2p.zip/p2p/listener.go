// Copyright Fuzamei Corp. 2018 All Rights Reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package p2p

import (
	"fmt"
	"net"
	"sync"
	"time"

	pb "github.com/33cn/chain33/types"
	"golang.org/x/net/context"
	"google.golang.org/grpc"
	"google.golang.org/grpc/keepalive"
	pr "google.golang.org/grpc/peer"
	"google.golang.org/grpc/stats"
)

// Listener the actions
type Listener interface {
	Close()
	Start()
}

// Start listener start
func (l *listener) Start() {
	l.p2pserver.Start()
	go l.server.Serve(l.netlistener)

}

// Close listener close
func (l *listener) Close() {
	l.netlistener.Close()
	go l.server.Stop()
	l.p2pserver.Close()
	log.Info("stop", "listener", "close")

}

type listener struct {
	server      *grpc.Server
	nodeInfo    *NodeInfo
	p2pserver   *P2pserver
	node        *Node
	netlistener net.Listener
}

// NewListener produce a listener object
func NewListener(protocol string, node *Node) Listener {
	log.Debug("NewListener", "localPort", defaultPort)
	l, err := net.Listen(protocol, fmt.Sprintf(":%v", defaultPort))
	if err != nil {
		log.Crit("Failed to listen", "Error", err.Error())
		return nil
	}

	dl := &listener{
		nodeInfo:    node.nodeInfo,
		node:        node,
		netlistener: l,
	}

	pServer := NewP2pServer()
	pServer.node = dl.node

	//一元拦截器 接口调用之前进行校验拦截
	interceptor := func(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (resp interface{}, err error) {
		//checkAuth
		getctx, ok := pr.FromContext(ctx)
		if !ok {
			return nil, fmt.Errorf("")
		}
		ip, _, _ := net.SplitHostPort(getctx.Addr.String())

		if pServer.node.nodeInfo.blacklist.Has(ip) {
			return nil, fmt.Errorf("this %v is not authorized", ip)
		}

		if !auth(conns, ip) {
			log.Error("interceptor", "auth faild", ip)
			//把相应的IP地址加入黑名单中
			pServer.node.nodeInfo.blacklist.Add(ip, int64(3600))

		}
		// Continue processing the request
		return handler(ctx, req)
	}
	//流拦截器
	interceptorStream := func(req interface{}, stream grpc.ServerStream, info *grpc.StreamServerInfo, handler grpc.StreamHandler) error {
		getctx, ok := pr.FromContext(stream.Context())
		if !ok {
			return fmt.Errorf("stream Context err")
		}
		ip, _, _ := net.SplitHostPort(getctx.Addr.String())

		if pServer.node.nodeInfo.blacklist.Has(ip) {
			return fmt.Errorf("this %v is not authorized", ip)
		}

		if !auth(conns, ip) {
			log.Error("interceptorStream", "auth faild", ip)
			//把相应的IP地址加入黑名单中
			pServer.node.nodeInfo.blacklist.Add(ip, int64(3600))
		}
		return handler(req, stream)
	}
	var opts []grpc.ServerOption
	opts = append(opts, grpc.UnaryInterceptor(interceptor), grpc.StreamInterceptor(interceptorStream))
	//区块最多10M
	msgRecvOp := grpc.MaxMsgSize(11 * 1024 * 1024)     //设置最大接收数据大小位11M
	msgSendOp := grpc.MaxSendMsgSize(11 * 1024 * 1024) //设置最大发送数据大小为11M
	var keepparm keepalive.ServerParameters
	keepparm.Time = 5 * time.Minute
	keepparm.Timeout = 50 * time.Second
	keepparm.MaxConnectionIdle = 1 * time.Minute
	maxStreams := grpc.MaxConcurrentStreams(1000)
	keepOp := grpc.KeepaliveParams(keepparm)
	StatsOp := grpc.StatsHandler(&statshandler{})
	opts = append(opts, msgRecvOp, msgSendOp, keepOp, maxStreams, StatsOp)
	dl.server = grpc.NewServer(opts...)
	dl.p2pserver = pServer
	pb.RegisterP2PgserviceServer(dl.server, pServer)
	return dl
}

type statshandler struct{}

func (h *statshandler) TagConn(ctx context.Context, info *stats.ConnTagInfo) context.Context {
	return context.WithValue(ctx, connCtxKey{}, info)

}

func (h *statshandler) TagRPC(ctx context.Context, info *stats.RPCTagInfo) context.Context {
	return ctx
}

func (h *statshandler) HandleConn(ctx context.Context, s stats.ConnStats) {
	if ctx == nil {
		return
	}
	tag, ok := getConnTagFromContext(ctx)
	if !ok {
		fmt.Println("can not get conn tag")
		return
	}
	switch s.(type) {
	case *stats.ConnBegin:
		connsMutex.Lock()
		defer connsMutex.Unlock()
		ip, _, _ := net.SplitHostPort(tag.RemoteAddr.String())

		conns[tag] = ip

		log.Debug("begin conn", "tag =", tag, "connsNum:", len(conns), "remoteAddr", tag.RemoteAddr.String(), "localAddr:", tag.LocalAddr.String())
	case *stats.ConnEnd:
		connsMutex.Lock()
		defer connsMutex.Unlock()
		delete(conns, tag)
		log.Debug("end conn", "tag:", tag, "connsNum:", len(conns), "remoteAddr", tag.RemoteAddr.String())
	default:
		log.Error("illegal ConnStats type\n")
	}

}

// HandleRPC 为空.
func (h *statshandler) HandleRPC(ctx context.Context, s stats.RPCStats) {

}

type connCtxKey struct{}

var connsMutex sync.Mutex
var conns map[*stats.ConnTagInfo]string = make(map[*stats.ConnTagInfo]string)

func getConnTagFromContext(ctx context.Context) (*stats.ConnTagInfo, bool) {
	tag, ok := ctx.Value(connCtxKey{}).(*stats.ConnTagInfo)
	return tag, ok
}
func auth(conns map[*stats.ConnTagInfo]string, checkIP string) bool {
	connsMutex.Lock()
	defer connsMutex.Unlock()
	var count int

	for _, v := range conns {

		if v == checkIP {
			count++
		}
	}

	if count > MaxSamIPNum {
		log.Error("AuthCheck", "sameIP num:", count, "checkIP:", checkIP, "conns num:", len(conns))
		return false
	}
	return true
}

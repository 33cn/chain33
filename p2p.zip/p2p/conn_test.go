package p2p

import (
	"fmt"
	"testing"
	"time"

	pb "github.com/33cn/chain33/types"
	"golang.org/x/net/context"
	"google.golang.org/grpc"
)

func TestGrpcConns(t *testing.T) {
	var conn *grpc.ClientConn
	var err error
	for i := 0; i < 30; i++ {
		fmt.Println("index:", i)
		conn, err = grpc.Dial("localhost:13802", grpc.WithInsecure(),
			grpc.WithDefaultCallOptions(grpc.UseCompressor("gzip")))
		if err != nil {
			fmt.Println("grpc DialCon", "did not connect", err)
			return
		}

		cli := pb.NewP2PgserviceClient(conn)

		resp, err := cli.GetHeaders(context.Background(), &pb.P2PGetHeaders{StartHeight: 0, EndHeight: 0, Version: 1002}, grpc.FailFast(true))

		if err != nil {
			fmt.Println("GetHeaders error:", err.Error())
			continue

		}
		fmt.Println(resp)

	}

	time.Sleep(time.Second * 5)
	return
}

func TestGrpcStreamConns(t *testing.T) {
	var conn *grpc.ClientConn
	var err error
	for i := 0; i < 30; i++ {
		fmt.Println("index:", i)
		conn, err = grpc.Dial("localhost:13802", grpc.WithInsecure(),
			grpc.WithDefaultCallOptions(grpc.UseCompressor("gzip")))
		if err != nil {
			fmt.Println("grpc DialCon", "did not connect", err)
			return
		}

		cli := pb.NewP2PgserviceClient(conn)
		//流测试
		ctx, _ := context.WithCancel(context.Background())
		var p2pdata pb.P2PGetData
		resp, err := cli.GetData(ctx, &p2pdata)
		if err != nil {
			fmt.Println("GetData error:", err.Error())
			continue

		}
		_, err = resp.Recv()
		if err != nil {
			fmt.Println("GetData error:", err.Error())
			continue

		}
		fmt.Println(resp)
	}
}

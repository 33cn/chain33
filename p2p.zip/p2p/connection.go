package p2p

import (
	"sync"

	pb "code.aliyun.com/chain33/chain33/types"
	"google.golang.org/grpc"
)

type MConnection struct {
	nodeInfo **NodeInfo
	gconn    *grpc.ClientConn
	conn     pb.P2PgserviceClient // source connection
	config   *MConnConfig
	key      string //privkey

	remoteAddress *NetAddress //peer 的地址
	peer          *peer
	once          sync.Once
}

// MConnConfig is a MConnection configuration.
type MConnConfig struct {
	gconn *grpc.ClientConn
	conn  pb.P2PgserviceClient
}

// DefaultMConnConfig returns the default config.
func DefaultMConnConfig() *MConnConfig {
	return &MConnConfig{}
}

func NewTemMConnConfig(gconn *grpc.ClientConn, conn pb.P2PgserviceClient) *MConnConfig {
	return &MConnConfig{
		gconn: gconn,
		conn:  conn,
	}
}

// NewMConnection wraps net.Conn and creates multiplex connection
func NewMConnection(conn *grpc.ClientConn, remote *NetAddress, peer *peer) *MConnection {

	mconn := &MConnection{
		gconn: conn,
		conn:  pb.NewP2PgserviceClient(conn),
		peer:  peer,
	}
	mconn.nodeInfo = peer.nodeInfo
	mconn.remoteAddress = remote

	return mconn

}

func NewMConnectionWithConfig(cfg *MConnConfig) *MConnection {
	mconn := &MConnection{
		gconn: cfg.gconn,
		conn:  cfg.conn,
	}

	return mconn
}

func (c *MConnection) Close() {

	c.gconn.Close()
	log.Debug("Mconnection", "Close", "^_^!")
}
